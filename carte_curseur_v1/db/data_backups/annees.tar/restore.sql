create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

DROP INDEX public.annee_idx;
DROP TABLE public.annees;
SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: annees; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE annees (
    annee integer
);


ALTER TABLE public.annees OWNER TO postgres;

--
-- Data for Name: annees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY annees (annee) FROM stdin;
\.
copy annees (annee)  from '$$PATH$$/2246.dat' ;
--
-- Name: annee_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX annee_idx ON annees USING btree (annee);


--
-- PostgreSQL database dump complete
--

